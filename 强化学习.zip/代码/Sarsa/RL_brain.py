import numpy as np
import pandas as pd


class RL(object):
    def __init__(self, actions, learning_rate=0.01, reward_decay=0.9, e_greedy=0.9):
        """
        初始化强化学习算法的基类（用于Q-learning和SARSA的实现）
        :param actions: 动作列表
        :param learning_rate: 学习率，控制Q值更新的步长
        :param reward_decay: 奖励衰减因子（gamma），决定未来奖励的重要性
        :param e_greedy: 探索率（epsilon），控制选择最优动作还是随机动作
        """
        self.actions = actions  # 动作列表
        self.lr = learning_rate  # 学习率
        self.gamma = reward_decay  # 奖励折扣因子
        self.epsilon = e_greedy  # 探索率
        # 初始化Q表，列为动作，行（状态）将动态添加，初始为空表
        self.q_table = pd.DataFrame(columns=self.actions, dtype=np.float64)

    def check_state_exist(self, state):
        """
        检查给定状态是否已经存在于Q表中，不存在则动态添加
        :param state: 当前状态
        """
        if state not in self.q_table.index:  # 如果状态不在Q表索引中
            # 为新状态创建一行，所有动作值初始化为0
            new_row = pd.Series([0] * len(self.actions), index=self.q_table.columns, name=state)
            self.q_table = pd.concat([self.q_table, new_row.to_frame().T], ignore_index=False)

    def choose_action(self, observation):
        """
        基于epsilon-greedy策略选择动作
        :param observation: 当前状态
        :return: 动作
        """
        self.check_state_exist(observation)  # 检查状态是否存在于Q表中
        # 根据epsilon值决定是选择最优动作还是随机动作
        if np.random.uniform() < self.epsilon:  # 以epsilon的概率选择最优动作
            state_action = self.q_table.loc[observation, :]  # 获取当前状态的所有动作值
            # 如果多个动作的Q值相同，则随机选择一个最优动作
            action = np.random.choice(state_action[state_action == np.max(state_action)].index)
        else:  # 否则随机选择一个动作
            action = np.random.choice(self.actions)
        return action

    def learn(self, *args):
        """
        学习方法，供子类（如Q-learning或SARSA）实现
        """
        pass


class SarsaTable(RL):
    def __init__(self, actions, learning_rate=0.01, reward_decay=0.9, e_greedy=0.9):
        """
        初始化SARSA算法的表格实现
        :param actions: 动作列表
        :param learning_rate: 学习率
        :param reward_decay: 奖励折扣因子（gamma）
        :param e_greedy: 探索率（epsilon）
        """
        super(SarsaTable, self).__init__(actions, learning_rate, reward_decay, e_greedy)  # 调用基类构造函数

    def learn(self, s, a, r, s_, a_):
        """
        SARSA算法的学习方法
        :param s: 当前状态
        :param a: 当前动作
        :param r: 奖励
        :param s_: 下一状态
        :param a_: 下一动作
        """
        self.check_state_exist(s_)  # 检查Q表中是否存在下一状态
        q_predict = self.q_table.loc[s, a]  # 获取预测的Q值
        if s_ != 'terminal':  # 如果下一状态不是终止状态
            q_target = r + self.gamma * self.q_table.loc[s_, a_]  # 使用SARSA公式计算目标值
        else:  # 如果下一状态是终止状态
            q_target = r  # 目标值仅为当前奖励
        # 更新Q值：Q(s, a) += lr * (q_target - q_predict)
        self.q_table.loc[s, a] += self.lr * (q_target - q_predict)


class SarsaLambdaTable(RL):
    def __init__(self, actions, learning_rate=0.01, reward_decay=0.9, e_greedy=0.9, trace_decay=0.9):
        """
        初始化SARSA(λ)算法的表格实现
        :param actions: 动作列表
        :param learning_rate: 学习率
        :param reward_decay: 奖励折扣因子（gamma）
        :param e_greedy: 探索率（epsilon）
        :param trace_decay: 资格迹衰减因子（lambda）
        """
        super(SarsaLambdaTable, self).__init__(actions, learning_rate, reward_decay, e_greedy)  # 调用基类构造函数
        self.lambda_ = trace_decay  # 设置资格迹衰减因子
        # 初始化资格迹表，与Q表形状相同，初始为空
        self.eligibility_trace = self.q_table.copy()

    def check_state_exist(self, state):
        """
        检查状态是否存在于Q表和资格迹表中，如果不存在则添加
        :param state: 当前状态
        """
        if state not in self.q_table.index:  # 如果状态不在Q表中
            # 为新状态创建一个全为0的行，添加到Q表和资格迹表中
            new_row = pd.Series([0] * len(self.actions), index=self.q_table.columns, name=state)
            self.q_table = pd.concat([self.q_table, new_row.to_frame().T], ignore_index=False)
            self.eligibility_trace = pd.concat([self.eligibility_trace, new_row.to_frame().T], ignore_index=False)

    def learn(self, s, a, r, s_, a_):
        """
        SARSA(λ)的学习方法，使用资格迹来更新Q值
        :param s: 当前状态
        :param a: 当前动作
        :param r: 当前动作的奖励
        :param s_: 下一状态
        :param a_: 下一动作
        """
        self.check_state_exist(s_)  # 检查下一状态是否存在于Q表中
        q_predict = self.q_table.loc[s, a]  # 获取预测的Q值
        if s_ != 'terminal':  # 如果下一状态不是终止状态
            q_target = r + self.gamma * self.q_table.loc[s_, a_]  # 使用SARSA(λ)公式计算目标值
        else:  # 如果下一状态是终止状态
            q_target = r  # 目标值仅为当前奖励
        error = q_target - q_predict  # 计算TD误差

        # 更新资格迹
        # 方法1：在当前状态-动作位置累加1
        # self.eligibility_trace.loc[s, a] += 1
        # 方法2：清除当前状态的所有动作资格迹值，仅为当前动作设置值为1
        self.eligibility_trace.loc[s, :] *= 0  # 清除当前状态的资格迹
        self.eligibility_trace.loc[s, a] = 1  # 当前状态-动作资格迹置为1

        # 更新Q值表：Q += lr * TD误差 * 资格迹
        self.q_table += self.lr * error * self.eligibility_trace

        # 衰减资格迹：资格迹 *= γ * λ
        self.eligibility_trace *= self.gamma * self.lambda_
