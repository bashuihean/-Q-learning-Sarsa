from maze_env import Maze  # 导入迷宫环境类
from Sarsa.RL_brain import SarsaTable  # 导入Sarsa表格版的强化学习算法
from Sarsa.RL_brain import SarsaLambdaTable  # 导入Sarsa(λ)算法（带资格迹的版本）

def update():
    """
    更新过程：每一回合中，智能体与环境交互，选择动作，更新Q表。
    训练过程：100回合，每回合智能体从初始状态开始，不断选择动作并更新Q值。
    """
    for episode in range(100):  # 设置训练的回合数为100
        observation = env.reset()  # 获取环境的初始状态（默认为起点(1, 1)）

        # 在初始状态下，选择一个动作
        action = RL.choose_action(str(observation))  # 基于当前观测选择一个动作

        while True:  # 在一个回合内持续选择动作，直到回合结束
            env.render()  # 刷新迷宫环境图形界面，显示当前状态

            # 根据当前的动作和状态，获取下一个状态和奖励
            observation_, reward, done = env.step(action)  # 执行动作，并获取新的状态、奖励及是否结束标志

            # 基于新的观测状态选择下一个动作
            action_ = RL.choose_action(str(observation_))  # 选择基于当前观察的下一个动作

            # 更新Sarsa表格：根据当前状态、动作、奖励和下一个状态及动作，更新Q表
            RL.learn(str(observation), action, reward, str(observation_), action_)

            # 更新当前状态和动作
            observation = observation_  # 设置为新的状态
            action = action_  # 设置为新的动作

            if done:  # 如果回合结束
                break  # 退出当前回合的循环

    print('end of game')  # 游戏结束提示
    env.destory()  # 销毁环境窗口，清理资源

# 程序入口
if __name__ == '__main__':
    env = Maze()  # 创建迷宫环境对象
    # 使用SarsaTable（基本版的SARSA算法）进行学习
    RL = SarsaTable(actions=list(range(env.n_actions)))
    # 如果需要使用SarsaLambda（带资格迹的SARSA），可以取消下行注释
    # RL = SarsaLambdaTable(actions=list(range(env.n_actions)))

    env.after(100, update)  # 延迟100毫秒后调用update函数，开始训练
    env.mainloop()  # 启动主事件循环，开始运行游戏/训练
