from maze_env import Maze  # 导入迷宫环境类
from QLearn.RL_brain import QLearningTable  # 导入QLearning算法类

# 定义游戏的更新逻辑
def update():
    for episode in range(100):  # 设置训练的回合数为100
        # 获取初始位置坐标信息（1，1）
        observation = env.reset()  # 重置环境，返回初始状态

        while True:  # 开始当前回合的循环
            # 刷新环境显示
            env.render()  # 更新迷宫图形界面，使环境的变化可视化

            # RL算法选择基于当前观测状态的下一个行为
            action = RL.choose_action(str(observation))
            # 将状态转化为字符串形式以便在Q表中进行索引，获取下一步动作

            # RL根据采取的行为执行环境步进，并获取下一个观测值、当前奖励以及回合结束标志
            observation_, reward, done = env.step(action)
            # observation_ 是新的状态，reward 是奖励，done 表示回合是否结束

            # RL学习方法：基于当前状态、动作、奖励和下一个状态，更新Q-table
            RL.learn(str(observation), action, reward, str(observation_))
            # Q-learning通过更新Q值来改进策略

            # 将当前状态更新为下一步的状态，为下次循环做准备
            observation = observation_

            # 如果本回合结束，则退出循环
            if done:
                break

    # 游戏结束提示
    print('end of game')
    env.destory()  # 销毁环境窗口

# 程序主入口
if __name__ == '__main__':
    env = Maze()  # 初始化迷宫环境
    # 初始化QLearningTable，动作列表是从迷宫环境中获取的可用动作索引
    RL = QLearningTable(actions=list(range(env.n_actions)))

    # 延迟100毫秒后调用update函数开始训练，保持图形界面流畅
    env.after(100, update)

    # 开始主事件循环，监听用户操作和更新界面
    env.mainloop()

