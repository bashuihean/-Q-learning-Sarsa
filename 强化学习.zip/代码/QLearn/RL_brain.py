import numpy as np
import pandas as pd


class QLearningTable:
    def __init__(self, actions, learning_rate=0.01, reward_decay=0.9, e_greedy=0.9):
        """
        初始化QLearningTable类。
        :param actions: 动作列表
        :param learning_rate: 学习率（控制Q值更新的步长）
        :param reward_decay: 奖励折扣因子（gamma）
        :param e_greedy: 探索率（epsilon），决定选择最优动作还是随机探索
        """
        self.actions = actions  # 动作列表
        self.lr = learning_rate  # 学习率
        self.gamma = reward_decay  # 奖励折扣因子
        self.epsilon = e_greedy  # 探索率
        # 初始化Q表，列为动作，行将动态添加，初始为空表
        self.q_table = pd.DataFrame(columns=self.actions, dtype=np.float64)

    def choose_action(self, observation):
        """
        根据当前状态选择动作。
        :param observation: 当前状态
        :return: 选择的动作
        """
        self.check_state_exist(observation)  # 检查Q表中是否存在该状态
        # 动作选择
        if np.random.uniform() < self.epsilon:  # 小于epsilon时选择最优动作
            # 获取当前状态的所有动作值
            state_action = self.q_table.loc[observation, :]
            # 如果多个动作值相同，则随机选择一个
            action = np.random.choice(state_action[state_action == np.max(state_action)].index)
        else:  # 大于epsilon时随机探索动作
            action = np.random.choice(self.actions)
        return action

    def learn(self, s, a, r, s_):
        """
        根据当前状态、动作、奖励和下一状态更新Q值。
        :param s: 当前状态
        :param a: 当前动作
        :param r: 当前动作的奖励
        :param s_: 下一状态
        """
        self.check_state_exist(s_)  # 确保Q表中有下一状态
        q_predict = self.q_table.loc[s, a]  # 获取预测的Q值
        if s_ != 'terminal':  # 如果下一状态不是终止状态
            q_target = r + self.gamma * self.q_table.loc[s_, :].max()  # 使用贝尔曼方程计算目标值
        else:  # 如果下一状态是终止状态
            q_target = r  # 目标值仅为当前奖励
        # Q值更新公式：Q(s,a) += lr * (q_target - q_predict)
        self.q_table.loc[s, a] += self.lr * (q_target - q_predict)

    def check_state_exist(self, state):
        """
        检查状态是否在Q表中，不存在则添加。
        :param state: 状态
        """
        if state not in self.q_table.index:  # 如果状态不在Q表的索引中
            # 创建一个新的状态行，动作值初始化为0
            new_row = pd.Series(
                [0] * len(self.actions),  # 动作值初始为0
                index=self.q_table.columns,  # 动作对应的列
                name=state,  # 设置索引为当前状态
            )
            # 添加新状态到Q表
            self.q_table = pd.concat([self.q_table, pd.DataFrame([new_row])])
