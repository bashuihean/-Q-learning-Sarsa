import numpy as np  # 导入NumPy库，用于数值计算
import time  # 导入time库，用于控制时间延迟
import sys  # 导入sys库，用于检查Python版本
if sys.version_info.major == 2:  # 如果是Python2
    import Tkinter as tk  # 导入Python2中的Tkinter模块
else:  # 如果是Python3
    import tkinter as tk  # 导入Python3中的tkinter模块

# 定义迷宫的单位格子大小
UNIT = 40  # 每个格子的大小（像素）
MAZE_H = 4  # 迷宫的高度（格子数）
MAZE_W = 4  # 迷宫的宽度（格子数）


class Maze(tk.Tk, object):
    def __init__(self):
        """
        初始化迷宫环境
        """
        super(Maze, self).__init__()  # 调用父类的构造函数，初始化tkinter窗口
        self.action_space = ['u', 'd', 'l', 'r']  # 定义四个动作：上、下、左、右
        self.n_actions = len(self.action_space)  # 动作的数量
        self.title('maze')  # 设置窗口标题
        self.geometry('{0}x{1}'.format(MAZE_H * UNIT, MAZE_H * UNIT))  # 设置窗口大小，依据迷宫的格子大小计算
        self._build_maze()  # 调用私有方法，构建迷宫

    def _build_maze(self):
        """
        创建迷宫的图形界面
        """
        self.canvas = tk.Canvas(self, bg='white',  # 创建一个白色背景的画布
                           height=MAZE_H * UNIT,
                           width=MAZE_W * UNIT)

        # 创建格子：竖直的线
        for c in range(0, MAZE_W * UNIT, UNIT):
            x0, y0, x1, y1 = c, 0, c, MAZE_H * UNIT
            self.canvas.create_line(x0, y0, x1, y1)  # 在画布上绘制一条竖直线
        # 创建格子：水平的线
        for r in range(0, MAZE_H * UNIT, UNIT):
            x0, y0, x1, y1 = 0, r, MAZE_W * UNIT, r
            self.canvas.create_line(x0, y0, x1, y1)  # 在画布上绘制一条水平线

        # 创建起点位置
        origin = np.array([20, 20])

        # 创建障碍物（黑色矩形），这里有两个障碍物
        hell1_center = origin + np.array([UNIT * 2, UNIT])  # 第一个障碍物的位置
        self.hell1 = self.canvas.create_rectangle(
            hell1_center[0] - 15, hell1_center[1] - 15,
            hell1_center[0] + 15, hell1_center[1] + 15,
            fill='black')  # 绘制第一个障碍物

        hell2_center = origin + np.array([UNIT, UNIT * 2])  # 第二个障碍物的位置
        self.hell2 = self.canvas.create_rectangle(
            hell2_center[0] - 15, hell2_center[1] - 15,
            hell2_center[0] + 15, hell2_center[1] + 15,
            fill='black')  # 绘制第二个障碍物

        # 创建目标（黄色圆形）
        oval_center = origin + UNIT * 2
        self.oval = self.canvas.create_oval(
            oval_center[0] - 15, oval_center[1] - 15,
            oval_center[0] + 15, oval_center[1] + 15,
            fill='yellow')  # 绘制目标位置

        # 创建智能体（红色矩形）
        self.rect = self.canvas.create_rectangle(
            origin[0] - 15, origin[1] - 15,
            origin[0] + 15, origin[1] + 15,
            fill='red')  # 绘制智能体初始位置

        # 将画布添加到窗口中
        self.canvas.pack()

    def reset(self):
        """
        重置环境，初始化智能体位置
        """
        self.update()  # 更新界面
        time.sleep(0.5)  # 暂停0.5秒
        self.canvas.delete(self.rect)  # 删除旧的智能体图像
        origin = np.array([20, 20])  # 重新设置起始位置
        self.rect = self.canvas.create_rectangle(
            origin[0] - 15, origin[1] - 15,
            origin[0] + 15, origin[1] + 15,
            fill='red')  # 创建新的智能体
        # 返回当前位置（智能体的坐标）
        return self.canvas.coords(self.rect)

    def step(self, action):
        """
        执行一个动作，移动智能体
        :param action: 当前动作（上、下、左、右）
        :return: 下一状态、奖励、是否结束标志
        """
        s = self.canvas.coords(self.rect)  # 获取当前状态（智能体的位置）
        base_action = np.array([0, 0])  # 初始化动作变化量
        if action == 0:   # 上
            if s[1] > UNIT:  # 防止越界
                base_action[1] -= UNIT
        elif action == 1:   # 下
            if s[1] < (MAZE_H - 1) * UNIT:  # 防止越界
                base_action[1] += UNIT
        elif action == 2:   # 右
            if s[0] < (MAZE_W - 1) * UNIT:  # 防止越界
                base_action[0] += UNIT
        elif action == 3:   # 左
            if s[0] > UNIT:  # 防止越界
                base_action[0] -= UNIT

        self.canvas.move(self.rect, base_action[0], base_action[1])  # 移动智能体

        s_ = self.canvas.coords(self.rect)  # 获取新的状态（新的坐标）

        # 奖励函数
        if s_ == self.canvas.coords(self.oval):  # 如果智能体到达目标位置
            reward = 1
            done = True  # 游戏结束
            s_ = 'terminal'  # 终止状态
        elif s_ in [self.canvas.coords(self.hell1), self.canvas.coords(self.hell2)]:  # 如果智能体进入障碍物
            reward = -1
            done = True  # 游戏结束
            s_ = 'terminal'  # 终止状态
        else:
            reward = 0  # 正常情况没有奖励
            done = False  # 游戏继续进行

        return s_, reward, done  # 返回新的状态、奖励和游戏是否结束的标志

    def render(self):
        """
        刷新界面
        """
        time.sleep(0.1)  # 每0.1秒刷新一次
        self.update()


def update():
    """
    更新训练过程中的状态
    """
    for t in range(10):  # 进行10回合训练
        s = env.reset()  # 重置环境，获取初始状态
        while True:
            env.render()  # 渲染当前状态
            a = 1  # 固定选择动作1（向下）
            s, r, done = env.step(a)  # 执行动作，获取新的状态、奖励和是否结束标志
            if done:  # 如果游戏结束，退出循环
                break


if __name__ == '__main__':
    env = Maze()  # 创建迷宫环境实例
    env.after(100, update)  # 延迟100毫秒后调用update函数开始训练
    env.mainloop()  # 启动tkinter主事件循环，开始运行迷宫游戏
